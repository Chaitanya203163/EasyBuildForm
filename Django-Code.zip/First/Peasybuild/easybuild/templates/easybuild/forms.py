from django import forms
from .models import EasyBuildSubmission

class EasyBuildForm(forms.ModelForm):
    class Meta:
        model = EasyBuildSubmission
        fields = '__all__'  # Use '__all__' to include all fields from the model

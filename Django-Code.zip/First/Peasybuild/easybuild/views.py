
from django.shortcuts import render

def submit_form(request):
    return render(request, 'easybuild/submit_form.html')


from django.db import models

class EasyBuildSubmission(models.Model):
    fieldExecutive = models.CharField(max_length=500)
    teamLeader = models.CharField(max_length=500)
    firmName = models.CharField(max_length=500)
    ownerName = models.CharField(max_length=500)
    district = models.CharField(max_length=100)
    contactNumber = models.CharField(max_length=100)
    primaryCategory = models.CharField(max_length=100)
    primaryCategoriesBrand = models.JSONField()
    primaryCategoriesVolume = models.JSONField()
    crossCategory = models.JSONField()
    crossCategoryBusiness = models.CharField(max_length=500)
    rewardProgramOthers = models.JSONField()
    dedicatedPerson = models.CharField(max_length=3, choices=[('yes', 'Yes'), ('no', 'No')])
    personName = models.CharField(max_length=500, blank=True, null=True)
    personMobile = models.CharField(max_length=100, blank=True, null=True)
    personEmail = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return self.firmName  # Change this to a relevant field that you want to display

    class Meta:
        verbose_name_plural = 'EasyBuild Submissions'

from django.shortcuts import render, redirect, HttpResponse
from .forms import MyDataForm
from .models import MyData
import xlsxwriter

def input_data(request):
    if request.method == 'POST':
        form = MyDataForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('thank_you')
    else:
        form = MyDataForm()
    return render(request, 'input_data.html', {'form': form})

def thank_you(request):
    return render(request, 'thank_you.html')

def view_data(request):
    all_data = MyData.objects.all()

    # Check if the user wants to download the data as Excel
    if request.GET.get('download'):
        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = 'attachment; filename="data.xlsx"'

        workbook = xlsxwriter.Workbook(response)
        worksheet = workbook.add_worksheet()

        # Write the header row
        header_row = ['Field1', 'Field2', 'Field3', 'Field4', 'Field5', 'Field6', 'Field7', 'Field8', 'Field9', 'Field10', 'Field11', 'Field12']
        for col_num, header in enumerate(header_row):
            worksheet.write(0, col_num, header)

        # Write data rows
        for row_num, data in enumerate(all_data, start=1):
            worksheet.write(row_num, 0, data.field1)
            worksheet.write(row_num, 1, data.field2)
            worksheet.write(row_num, 2, data.field3)
            worksheet.write(row_num, 3, data.field4)
            worksheet.write(row_num, 4, data.field5)
            worksheet.write(row_num, 5, data.field6)
            worksheet.write(row_num, 6, data.field7)
            worksheet.write(row_num, 7, data.field8)
            worksheet.write(row_num, 8, data.field9)
            worksheet.write(row_num, 9, data.field10)
            worksheet.write(row_num, 10, data.field11)
            worksheet.write(row_num, 11, data.field12)

        workbook.close()
        return response

    return render(request, 'view_data.html', {'all_data': all_data})

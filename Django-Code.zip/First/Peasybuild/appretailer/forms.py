from django import forms
from .models import MyData

class MyDataForm(forms.ModelForm):
    class Meta:
        model = MyData
        fields = ('field1', 'field2', 'field3', 'field4', 'field5', 'field6',
                  'field7', 'field8', 'field9', 'field10', 'field11', 'field12',)

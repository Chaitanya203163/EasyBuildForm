from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='MyData',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('field1', models.CharField(max_length=100)),
                ('field2', models.CharField(max_length=100)),
                ('field3', models.CharField(max_length=100)),
                ('field4', models.CharField(max_length=100)),
                ('field5', models.CharField(max_length=100)),
                ('field6', models.CharField(max_length=100)),
                ('field7', models.CharField(max_length=100)),
                ('field8', models.CharField(max_length=100)),
                ('field9', models.CharField(max_length=100)),
                ('field10', models.CharField(max_length=100)),
                ('field11', models.CharField(max_length=100)),
                ('field12', models.CharField(max_length=100)),
                ('saved_at', models.DateTimeField(auto_now_add=True)),  # New field for saving the timestamp
            ],
        ),
    ]
